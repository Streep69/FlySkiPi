
from flask import Flask, render_template_string, request, session

app = Flask(__name__)
app.secret_key = "flyskypi_secret_key"

@app.route("/")
def home():
    return render_template_string("""
<h1 style='color:red; background:black; text-align:center; padding:2em;'>FLYSKYPI LIVE</h1>
<p style='text-align:center;'>Secure Dashboard | Docs | Auto-Deploy</p>
<p style='text-align:center;'><a href='/admin'>Enter Admin Panel</a></p>
"""
)

@app.route("/admin", methods=["GET", "POST"])
def admin():
    if request.method == "POST":
        if request.form.get("pw") == "flyadmin":
            session["auth"] = True
        else:
            return "Denied", 403
    if not session.get("auth"):
        return '''
        <form method="post"><input name="pw" type="password" placeholder="Admin Password">
        <input type="submit" value="Login"></form>'''
    return render_template_string("<h2 style='color:white; background:#111;'>Welcome to FlySkyPi Secure Admin</h2>")
