#!/usr/bin/env bash
###############################################################################
# FortressPi MASTER INSTALLER
# Deploys all modules: core, upload panel, Webmin, monitoring, backup, webhook,
# watchdog, HTTPS reverse proxy, Samba share, CI/CD runner.
# Run as root inside /mnt/fortressshare/FortressPi_X304
###############################################################################
set -euo pipefail
LOG=/var/log/fortresspi_master_install.log
exec > >(tee -a "$LOG") 2>&1
echo "[*] FortressPi master install started $(date)"

### 0. Prerequisite apt packages ##############################################
echo "[*] Installing global dependencies..."
apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y \
    git curl wget dos2unix rsync jq ufw fail2ban \
    docker.io docker-compose-plugin \
    nginx php-cli php-fpm \
    webmin samba prometheus-node-exporter \
    mkcert python3 python3-pip

systemctl enable --now docker
id -nG pi | grep -qw docker || usermod -aG docker pi

### 1. Shared directories ######################################################
echo "[*] Creating shared folders..."
mkdir -p /mnt/fortressshare/uploads
mkdir -p /srv/fortressshare
mkdir -p /home/pi/gpt4free/{har_and_cookies,generated_media,logs}
mkdir -p /var/www/upload_cli /var/www/upload_fpm
chown -R pi:pi /home/pi/gpt4free
chown -R www-data:www-data /mnt/fortressshare/uploads /var/www/upload_cli /var/www/upload_fpm

### 2. Helper to run local installers #########################################
run_if_exists() {
  local scr=$1
  if [[ -x $scr ]]; then
    echo "[*] Executing $scr"
    "$scr"
  else
    echo "[!] $scr missing or not executable – skipped"
  fi
}

### 3. Unzip module zips (if not already) #####################################
for z in fortresspi_*.zip; do
  echo "[*] Unpacking $z"
  unzip -o "$z"
done

### 4. Execute installers in logical order ####################################
run_if_exists ./install_core.sh              # GPT-4Free core
run_if_exists ./install_upload_panel.sh      # dual upload panels
run_if_exists ./install_webmin.sh            # Webmin UI
run_if_exists ./install_monitoring.sh        # Node exporter
run_if_exists ./install_reverseproxy_ssl.sh  # HTTPS proxy
run_if_exists ./install_webhook.sh           # Copilot webhook
run_if_exists ./install_watchdog.sh          # watchdog timer
run_if_exists ./install_samba_sync.sh        # Samba share + sync
run_if_exists ./install_cicd_runner.sh       # GitHub runner
echo "[*] All installers executed."

### Run Enhanced GPT-4Free Validator ##########################################
if [[ -x ./validator_core.sh ]]; then
  ./validator_core.sh
fi
if [[ -x ./fortresspi_validator.sh ]]; then
  ./fortresspi_validator.sh
fi

### 5. Firewall ################################################################
echo "[*] Configuring UFW..."
ufw allow 22 443 10000 1337 8080 8081 8082 7900 9100 9123
ufw --force enable

### 6. Validate core services ##################################################
if [[ -x ./validator_core.sh ]]; then
  ./validator_core.sh
fi
if [[ -x ./fortresspi_validator.sh ]]; then
  ./fortresspi_validator.sh
fi

echo "[✔] FortressPi master install finished $(date)"
