#!/bin/bash
BACKUP_DIR="/mnt/fortress_backups"
TIMESTAMP=$(date +%Y%m%d-%H%M%S)
DEST="$BACKUP_DIR/backup_$TIMESTAMP"

mkdir -p "$DEST"
cp -r /opt/fortresspi-dashboard "$DEST/dashboard" 2>/dev/null
cp -r /opt/fortresspi-gpt "$DEST/gpt" 2>/dev/null
cp -r /etc/webmin "$DEST/webmin" 2>/dev/null
cp -r /etc/fortresspi "$DEST/config" 2>/dev/null
cp -r /var/log/fortresspi "$DEST/logs" 2>/dev/null

# Keep only the 5 most recent backups
cd "$BACKUP_DIR"
ls -dt backup_* | tail -n +6 | xargs -r rm -rf

echo "Backup complete: $DEST"
