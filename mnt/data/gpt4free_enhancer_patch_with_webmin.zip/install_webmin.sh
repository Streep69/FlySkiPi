#!/bin/bash
echo "[*] Installing Webmin..."
sudo apt update
sudo apt install -y software-properties-common apt-transport-https wget
wget -qO - http://www.webmin.com/jcameron-key.asc | sudo apt-key add -
sudo add-apt-repository "deb http://download.webmin.com/download/repository sarge contrib"
sudo apt update
sudo apt install -y webmin
echo "[+] Webmin installed. Access it at https://<your-ip>:10000"
