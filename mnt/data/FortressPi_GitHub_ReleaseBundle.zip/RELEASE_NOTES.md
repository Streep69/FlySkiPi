
# FortressPi v22.0 - Validated Release

This release includes:

- ✅ Fully validated Flask dashboard (with theme switch, backup UI, login)
- ☁️ Cloud backup via GitHub Actions & rclone
- 🔄 Local ZIP archiver with `backup_logic.sh`
- 🔍 Metadata + Chat audit trace in `LogicAudit_Manifest`

To deploy:
1. Unzip
2. Run `app.py` via Flask
3. Configure GitHub Actions + Secrets for cloud sync
