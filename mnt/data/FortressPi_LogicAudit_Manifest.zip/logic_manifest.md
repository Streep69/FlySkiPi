
# FortressPi Logic Manifest

## Core Modules
- app.py — Flask UI logic with backup, login, theme toggle
- backup_logic.sh — Local ZIP archiving script
- fortresspi_dashboard_backup_snippet.html — UI form for backup buttons
- bloody.css / moonlight.css — Theme support
- theme_switcher.js — JavaScript toggle
- fortresspi.service — Systemd unit for startup

## GitHub Setup
- Repo: github.com/Streep69/FlySkiPi
- Secrets Required:
  - GH_PAT (for pushing)
  - RCLONE_CONFIG (for Google Drive)
- Deploy Flow:
  - Tag release `v22.x`
  - GitHub Action `cloud-backup.yml` auto-uploads metadata
  - Files released include ZIP bundles + logs
