#!/usr/bin/env bash
###############################################################################
# FortressPi MASTER INSTALLER
# Deploys all modules in proper order and validates the system.
###############################################################################
set -euo pipefail
LOG=/var/log/fortresspi_master_install.log
exec > >(tee -a "$LOG") 2>&1

echo "[*] FortressPi master install started $(date)"

### 0. Global prerequisites ###################################################
echo "[*] Installing global dependencies..."
apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y \
    git curl wget dos2unix rsync jq ufw fail2ban \
    docker.io docker-compose-plugin \
    nginx php8.0 php8.0-fpm php8.0-cli \
    webmin samba prometheus-node-exporter \
    mkcert python3 python3-pip

systemctl enable --now docker
id -nG pi | grep -qw docker || usermod -aG docker pi || true

### 1. Create required directories ############################################
mkdir -p /mnt/fortressshare/uploads
mkdir -p /srv/fortressshare
mkdir -p /home/pi/gpt4free/{har_and_cookies,generated_media,logs}
mkdir -p /var/www/upload_cli /var/www/upload_fpm
chown -R pi:pi /home/pi/gpt4free
chown -R www-data:www-data /mnt/fortressshare/uploads /var/www/upload_cli /var/www/upload_fpm

### 2. Helper function to execute scripts ####################################
run_if_exists() {
  local scr=$1
  if [[ -x $scr ]]; then
    echo "[*] Executing $scr"
    "$scr"
  else
    echo "[!] $scr missing or not executable – skipped"
  fi
}

### 3. Unpack all fortresspi_*.zip modules ###################################
for z in fortresspi_*.zip; do
  echo "[*] Unpacking $z"
  unzip -o "$z"
done

### 4. Run all installers #####################################################
run_if_exists ./fortresspi_core/install_core.sh
run_if_exists ./fortresspi_uploadpanel/install_upload_panel.sh
run_if_exists ./fortresspi_webmin/install_webmin.sh
run_if_exists ./fortresspi_monitoring/install_monitoring.sh
run_if_exists ./fortresspi_reverseproxy/install_reverseproxy.sh
run_if_exists ./fortresspi_webhook/install_webhook.sh
run_if_exists ./fortresspi_watchdog/install_watchdog.sh
run_if_exists ./fortresspi_samba/install_samba.sh
run_if_exists ./fortresspi_backup/install_backup.sh

echo "[*] All installers executed."

### 5. Firewall settings ######################################################
echo "[*] Configuring firewall (UFW)..."
ufw allow 22 80 443 10000 1337 8080 8081 8082 7900 9100 9123
ufw --force enable

### 6. Run validation scripts #################################################
if [[ -x ./fortresspi_core/validator_core.sh ]]; then
  ./fortresspi_core/validator_core.sh || echo "✗ Core validation failed"
fi

if [[ -x ./fortresspi_all_modules_v2-2/fortresspi_validator.sh ]]; then
  ./fortresspi_all_modules_v2-2/fortresspi_validator.sh || echo "✗ Master validation failed"
fi

echo "[✔] FortressPi master installation and validation complete $(date)"
