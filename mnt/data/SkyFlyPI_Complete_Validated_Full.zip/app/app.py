from flask import Flask, render_template_string, request, session, redirect, url_for

app = Flask(__name__)
app.secret_key = "change_this_secret_key_123"

@app.route("/")
def home():
    return render_template_string("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>SkyFlyPI</title>
        <style>
            body { background: black; color: red; font-family: monospace; text-align: center; padding-top: 50px; }
            a { color: #ff5555; text-decoration: none; }
            a:hover { text-decoration: underline; }
        </style>
    </head>
    <body>
        <h1>SkyFlyPI Secure Mode</h1>
        <p>Diagnostics | Dashboard | GPT UI</p>
        <p><a href="/admin">Go to Dashboard</a></p>
    </body>
    </html>
    """)

@app.route("/admin", methods=["GET", "POST"])
def admin():
    if request.method == "POST":
        if request.form.get("pw") == "fortress123":
            session["auth"] = True
            return redirect(url_for("admin"))
        else:
            return render_template_string("""
            <h3 style='color:red;'>Access Denied</h3>
            <a href='/admin'>Try again</a>
            """)
    if not session.get("auth"):
        return render_template_string("""
        <form method="post" style="text-align:center; margin-top:100px;">
            <input name="pw" type="password" placeholder="Enter Password" />
            <input type="submit" value="Login" />
        </form>
        """)
    return render_template_string("""
    <h2 style='color:white; background:#111; padding:1em;'>Admin Panel - SkyFlyPI</h2>
    <ul style="color:white;">
        <li>Status: <span style='color:lime;'>OK</span></li>
        <li>Uptime: 99.99%</li>
        <li>Modules: GPT UI, Watchdog, Dashboard</li>
    </ul>
    """)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)