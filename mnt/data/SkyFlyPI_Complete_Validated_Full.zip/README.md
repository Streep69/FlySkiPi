# SkyFlyPI
Secure AI dashboard hosted on Fly.io with GitHub automation.
