#!/bin/bash
cd /mnt/fortresshare
echo "==== Running Force88 ===="
python3 force88_github_sync.py
echo "==== Running Force89 ===="
python3 force89_context_logger.py
echo "==== End Smoke Test ===="