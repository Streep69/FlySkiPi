FortressPi Portable USB Bundle
================================

CONTENTS:
---------
- FortressPi_AllinOne_Validated.zip  --> Full system bundle
- auto_deploy_fortresspi.sh          --> One-click deploy script

HOW TO USE:
-----------
1. Copy this folder to a USB drive (FAT32 or ext4 recommended).
2. Insert into any Debian-based Linux system.
3. Open a terminal and run:
   chmod +x auto_deploy_fortresspi.sh
   ./auto_deploy_fortresspi.sh

This will deploy FortressPi to /mnt/fortressshare/ with full services.

NOTES:
------
- Requires sudo access
- Internet connection needed on first install (for apt/dpkg)
- Web UI: http://<your-ip>/admin/ (user: admin / password: fortresspi)

