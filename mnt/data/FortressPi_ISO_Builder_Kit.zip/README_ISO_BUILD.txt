FortressPi ISO Builder Kit
============================

This kit prepares a fully persistent, GUI-enabled, installable FortressPi OS
based on Ubuntu (for x86) or Raspberry Pi OS (for ARM).

REQUIREMENTS:
-------------
- Ubuntu system with `cubic` (for x86 ISO)
- Pi-gen or `debuild` + `live-build` for Raspberry Pi OS (arm64)

CONTENT:
--------
- fortresspi_root/ : Contents to inject into custom ISO filesystem
- auto_deploy_fortresspi.sh : Auto-deployment script
- FortressPi_AllinOne_Validated.zip : System bundle
- fortresspi_usb_launcher.sh : GUI launcher
- FortressPi_USB_Installer.desktop : Desktop shortcut

INSTRUCTIONS (x86 Ubuntu ISO with Cubic):
------------------------------------------
1. Install cubic: sudo apt install cubic
2. Launch cubic and:
   - Select Ubuntu ISO as base (22.04 recommended)
   - In the terminal view, copy contents of `fortresspi_root/` into `/`
     (e.g., cp -r /path/to/fortresspi_root/* /)
   - Update permissions: chmod +x /auto_deploy_fortresspi.sh
   - Create user `fortress` (auto-login, sudo access)
   - Exit terminal and build ISO

After building, burn to USB and boot.

