#!/bin/bash
set -e

echo "[*] Starting GPT4Free Docker installer..."

# Cleanup previous installations
docker stop gpt4free || true
docker rm gpt4free || true
docker volume rm $(docker volume ls -qf dangling=true) || true

# Install Docker and dependencies
sudo apt-get update
sudo apt-get install -y docker.io docker-compose git curl ufw

# Clone repo if not exists
if [ ! -d "gpt4free" ]; then
  git clone https://github.com/xtekky/gpt4free
fi

cd gpt4free

# Modify docker-compose to use port 8045
sed -i 's/1337:1337/8045:1337/' docker-compose.yml || true

# Start container
docker-compose up -d

# Firewall rules
sudo ufw allow 8045/tcp
sudo ufw allow 1337/tcp
sudo ufw allow 10000/tcp

# Log and test
echo "[*] Installation complete." | tee /mnt/fortressshare/logs/gpt4free-install.log
docker ps | tee -a /mnt/fortressshare/logs/gpt4free-install.log

curl -I http://localhost:8045 || echo "Service not responding on port 8045"

