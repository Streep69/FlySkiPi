# GPT4Free Auto Installer

Run `sudo ./install_gpt4free.sh` to install and validate.