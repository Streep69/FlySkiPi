#!/bin/bash
if ! command -v zenity >/dev/null; then
  echo "Zenity is not installed. Install with: sudo apt install zenity"
  exit 1
fi

zenity --info --width=300 --title="FortressPi USB Installer" \
  --text="This will deploy FortressPi from USB into /mnt/fortressshare.\n\nYou must have sudo access."

if zenity --question --title="Proceed with Installation?" --text="Do you want to run the installer now?"; then
  gnome-terminal -- bash -c "sudo ./auto_deploy_fortresspi.sh; exec bash"
else
  zenity --info --text="Installation canceled."
fi
