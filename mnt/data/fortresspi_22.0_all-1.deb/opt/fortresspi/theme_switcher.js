
function toggleTheme() {
  const current = localStorage.getItem('theme') || 'bloody';
  const next = current === 'bloody' ? 'moonlight' : 'bloody';
  localStorage.setItem('theme', next);
  document.getElementById('theme-css').href = `/static/css/${next}.css`;
}
window.onload = () => {
  const current = localStorage.getItem('theme') || 'bloody';
  document.getElementById('theme-css').href = `/static/css/${current}.css`;
};
