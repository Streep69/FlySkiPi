#!/bin/bash
set -e

echo "[+] Cleaning old gpt4free containers (if any)..."
docker stop gpt4free || true
docker rm gpt4free || true

echo "[+] Installing Docker (if not present)..."
if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com -o get-docker.sh
    sh get-docker.sh
fi

echo "[+] Creating required folders..."
mkdir -p $PWD/har_and_cookies $PWD/generated_media $PWD/logs
chown -R 1000:1000 $PWD/har_and_cookies $PWD/generated_media

echo "[+] Pulling GPT4Free Docker image..."
docker pull hlohaus789/g4f:latest-slim

echo "[+] Launching GPT4Free (WebUI:8045, API:1337)..."
docker run -d \
  --name gpt4free \
  -p 8045:8080 -p 1337:1337 \
  -v $PWD/har_and_cookies:/app/har_and_cookies \
  -v $PWD/generated_media:/app/generated_media \
  hlohaus789/g4f:latest-slim \
  /bin/sh -c 'rm -rf /app/g4f && pip install -U g4f[slim] && python -m g4f --debug'

echo "[+] Setup complete! Access WebUI at http://localhost:8045/chat or API at http://localhost:1337"
