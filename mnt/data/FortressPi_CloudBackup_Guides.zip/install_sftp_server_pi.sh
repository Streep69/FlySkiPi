#!/bin/bash
echo "🔧 Installing OpenSSH for SFTP..."

sudo apt-get update
sudo apt-get install -y openssh-server

# Confirm SSH enabled
sudo systemctl enable ssh
sudo systemctl start ssh

# Create sftp user if needed
read -p "Enter username for SFTP (default: fortress): " user
user=${user:-fortress}

sudo adduser --disabled-password --gecos "" $user
sudo mkdir -p /home/$user/sftp
sudo chown root:root /home/$user
sudo chmod 755 /home/$user
sudo chown $user:$user /home/$user/sftp

echo "✅ SFTP user created: $user"
echo "📂 Upload folder: /home/$user/sftp"
