
# 🛡️ FortressPi Documentation

Welcome to the official documentation for **FortressPi**.

---

## 🚀 Quick Start

### 🧱 Install via `.deb`
```bash
sudo dpkg -i fortresspi_22.0_all.deb
```

### 🖥️ Or Run Manually
```bash
unzip FortressPi_v22_Integrated_FULL.zip -d fortresspi
cd fortresspi
pip3 install flask
nohup python3 app.py > fortresspi.log 2>&1 &
```

### 🌐 Access the Dashboard
```http
http://<your-pi-ip>:5000
```

---

## 🧪 Validator Tool

Run:
```bash
./validate_fortresspi_zip.sh FortressPi_v22_Integrated_FULL.zip
```

---

## 🔁 Auto-Deploy via GitHub & Fly.io

- Push to `main` triggers CI/CD.
- Add `FLY_API_TOKEN` to GitHub Secrets.

See `.github/workflows/fly-deploy.yml` for pipeline details.

---

MIT License – FortressPi Project
