#!/usr/bin/env python3
import os, shutil, subprocess, json, datetime

CONFIG_PATH = "/opt/fortresspi_updater/update_config.json"
STATE_PATH = "/opt/fortresspi_updater/version_state.json"
BACKUP_DIR = "/opt/fortresspi_updater/backups"

def log(msg):
    print(f"[UPDATE] {msg}")

def load_json(path):
    if os.path.exists(path):
        with open(path, 'r') as f:
            return json.load(f)
    return {}

def save_json(path, data):
    with open(path, 'w') as f:
        json.dump(data, f, indent=2)

def backup_module(module_path, module_name):
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    dest = os.path.join(BACKUP_DIR, f"{module_name}_{ts}")
    shutil.copytree(module_path, dest)
    log(f"Backup of {module_name} created at {dest}")

def run_update():
    config = load_json(CONFIG_PATH)
    state = load_json(STATE_PATH)

    for module in config.get("modules", []):
        name = module["name"]
        source = module["source"]
        current_version = state.get(name, "none")
        new_version = module["version"]

        log(f"Checking {name}... current={current_version}, available={new_version}")
        if new_version != current_version:
            log(f"Updating {name}...")
            # Backup current module
            module_path = f"/opt/{name}"
            if os.path.exists(module_path):
                backup_module(module_path, name)
            # Git clone or unzip update
            if source.startswith("http"):
                subprocess.run(["git", "clone", "--depth=1", source, module_path], check=True)
            elif source.endswith(".zip"):
                subprocess.run(["unzip", "-o", source, "-d", module_path], check=True)
            else:
                log(f"Unknown source format for {name}")
                continue
            state[name] = new_version
            log(f"{name} updated to {new_version}")
        else:
            log(f"{name} is up to date.")
    save_json(STATE_PATH, state)

if __name__ == "__main__":
    run_update()
