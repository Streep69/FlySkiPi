#!/bin/bash
set -e

echo "[+] Starting GPT4Free validated installer with full logic..."

# Clean environment
docker stop gpt4free || true
docker rm gpt4free || true

# Install Docker and docker-compose if missing
if ! command -v docker &> /dev/null; then
  echo "[*] Installing Docker..."
  sudo apt-get update
  sudo apt-get install -y docker.io
fi

if ! command -v docker-compose &> /dev/null; then
  echo "[*] Installing Docker Compose..."
  sudo apt-get install -y docker-compose
fi

# Prepare directory
if [ ! -d "gpt4free" ]; then
  echo "[*] Cloning GPT4Free..."
  git clone https://github.com/xtekky/gpt4free
fi
cd gpt4free

# Patch docker-compose
if grep -q '1337:1337' docker-compose.yml; then
  sed -i 's/1337:1337/8045:1337/g' docker-compose.yml
fi

# Launch the container
echo "[*] Launching container..."
docker-compose pull
docker-compose build
docker-compose up -d

# Firewall adjustments
sudo ufw allow 8045/tcp || true

# Log results
LOGDIR=/mnt/fortressshare/logs
mkdir -p $LOGDIR
docker ps > $LOGDIR/gpt4free_container_status.log
curl -s http://localhost:8045 > $LOGDIR/gpt4free_web_output.html || echo "Service not ready" >> $LOGDIR/gpt4free_web_output.html

echo "[✔] GPT4Free is installed and running on http://localhost:8045"
