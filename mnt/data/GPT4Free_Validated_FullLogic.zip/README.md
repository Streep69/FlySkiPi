# GPT4Free Full Logic Installer

Run with:
```bash
sudo ./install_gpt4free.sh
```