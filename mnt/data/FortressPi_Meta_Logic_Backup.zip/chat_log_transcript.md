## Chat Summary

All assistant and user messages organized by session.