from flask import Flask, render_template_string, request, session

app = Flask(__name__)
app.secret_key = "replace_this_secure_key"

@app.route("/")
def home():
    return render_template_string("""
    <h1 style='color:red; background:black; text-align:center; padding:2em;'>SkyFlyPI Secure Mode</h1>
    <p style='text-align:center;'>Diagnostics | Dashboard | GPT UI</p>
    <p style='text-align:center;'><a href='/admin'>Go to Dashboard</a></p>
    """)

@app.route("/admin", methods=["GET", "POST"])
def admin():
    if request.method == "POST":
        if request.form.get("pw") == "fortress123":
            session["auth"] = True
        else:
            return "Access Denied", 403
    if not session.get("auth"):
        return render_template_string("""
        <form method="post" style="text-align:center;">
            <input name="pw" type="password" placeholder="Enter Password" />
            <input type="submit" value="Login" />
        </form>
        """)
    return render_template_string("""
    <h2 style='color:white; background:#111; padding:1em;'>Admin Panel - SkyFlyPI</h2>
    """)