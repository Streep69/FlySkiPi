#!/bin/bash
# reset_pi_password.sh
#
# Reads configuration from reset_pi_password.conf (same directory)
# and resets the specified user's password to the one in config.

# Ensure running as root
if [ "$EUID" -ne 0 ]; then
  echo "This script must be run as root." >&2
  exit 1
fi

# Determine script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

CONFIG_FILE="$SCRIPT_DIR/reset_pi_password.conf"

# Check config exists
if [ ! -f "$CONFIG_FILE" ]; then
  echo "Configuration file not found at $CONFIG_FILE" >&2
  exit 1
fi

# Load config variables
source "$CONFIG_FILE"

# Validate variables
if [ -z "$TARGET_USER" ] || [ -z "$NEW_PASSWORD" ]; then
  echo "Config file must define TARGET_USER and NEW_PASSWORD" >&2
  exit 1
fi

# Check user exists
if ! id "$TARGET_USER" &>/dev/null; then
  echo "User '$TARGET_USER' does not exist." >&2
  exit 1
fi

# Reset password
echo "${TARGET_USER}:${NEW_PASSWORD}" | chpasswd

if [ $? -eq 0 ]; then
  echo "Password for user '$TARGET_USER' has been reset successfully."
else
  echo "Failed to reset password for '$TARGET_USER'." >&2
  exit 1
fi

exit 0
