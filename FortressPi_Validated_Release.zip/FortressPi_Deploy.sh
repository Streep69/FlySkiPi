#!/usr/bin/env bash
set -euo pipefail
LOG=/var/log/fortresspi_deploy.log
exec > >(tee -a "$LOG") 2>&1

echo "[*] Starting full FortressPi deployment..."

# Create working directory
WORKDIR="/opt/fortresspi_deployment"
mkdir -p "$WORKDIR"
cd "$WORKDIR"

# Copy all fortresspi_*.zip modules from the same directory
cp /mnt/data/fortresspi_*.zip .

# Unpack all modules
for z in fortresspi_*.zip; do
  echo "[*] Extracting $z..."
  unzip -o "$z" -d "${z%.zip}"
done

# Move master script to top
cp /mnt/data/fortresspi_all_modules_v2-2/install_fortresspi_master.sh .

# Run the master installer
chmod +x install_fortresspi_master.sh
./install_fortresspi_master.sh

echo "[✔] Full FortressPi system deployment complete."
