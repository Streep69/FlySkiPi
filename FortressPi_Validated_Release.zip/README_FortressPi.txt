FortressPi: Full Modular Installation Guide
===========================================

This package contains all modules and installation scripts for FortressPi,
a modular GPT-4Free and admin environment for Raspberry Pi (or x86 Linux).

INCLUDED MODULES:
------------------
- Core (GPT-4Free)
- Upload Panels (CLI + FPM)
- Webmin Admin UI
- Monitoring (Prometheus Node Exporter)
- HTTPS Reverse Proxy
- Webhook Listener (Flask)
- Samba File Share
- Watchdog Service
- Backup Scheduler
- Master Installer

INSTALLATION STEPS:
--------------------
1. Extract everything into a Linux system (preferably Debian-based).
2. Run:
   sudo bash FortressPi_Deploy.sh
3. Monitor log at:
   /var/log/fortresspi_deploy.log

NETWORK PORTS USED:
--------------------
- 22   (SSH)
- 80   (HTTP)
- 443  (HTTPS)
- 10000 (Webmin)
- 1337, 8080, 8081, 8082 (GPT-4Free, upload)
- 9100 (Monitoring)
- 9123 (Webhook)
- Samba ports (auto-configured)

DEFAULT LOCATIONS:
--------------------
- GPT-4Free: /home/pi/gpt4free
- Uploads: /mnt/fortressshare/uploads
- Samba share: /srv/fortressshare
- Logs: /var/log/fortresspi_*.log

SUPPORT:
--------
https://github.com/fortresspi (placeholder)

