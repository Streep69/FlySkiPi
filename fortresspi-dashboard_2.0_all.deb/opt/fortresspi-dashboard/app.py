#!/usr/bin/env python3
from flask import Flask, render_template, request, redirect, url_for
import subprocess

app = Flask(__name__)

def run(cmd):
    return subprocess.getoutput(cmd)

@app.route('/')
def index():
    status = {
        'gpt4free': 'g4f' in run("docker ps"),
        'upload_cli': 'active' in run("systemctl is-active upload-panel-cli.service"),
        'watchdog': 'active' in run("systemctl is-active fortresspi_watcher.timer"),
        'webhook': 'active' in run("systemctl is-active fortresspi_webhook.service")
    }
    return render_template('index.html', status=status)

@app.route('/restart/<service>')
def restart(service):
    if service == "gpt4free":
        run("cd /home/pi/gpt4free && docker compose restart")
    else:
        run(f"systemctl restart {service}")
    return redirect(url_for('index'))

@app.route('/logs/<target>')
def logs(target):
    if target == "gpt4free":
        out = run("docker logs g4f --tail 100")
    else:
        out = run(f"journalctl -u {target} -n 100")
    return f"<pre>{out}</pre>"

@app.route('/backup')
def manual_backup():
    out = run("/usr/local/bin/fortresspi_backup.sh")
    return f"<pre>{out}</pre>"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8090)


@app.route('/update')
def update_system():
    out = run("python3 /opt/fortresspi_updater/update.py")
    return f"<pre>{out}</pre>"

@app.route('/admin/diagnostics')
def diagnostics():
    import psutil, subprocess, time

    metrics = []
    metrics.append(f"Uptime: {time.strftime('%H:%M:%S', time.gmtime(time.time() - psutil.boot_time()))}")
    metrics.append(f"CPU Usage: {psutil.cpu_percent()}%")
    metrics.append(f"RAM Usage: {psutil.virtual_memory().percent}%")
    metrics.append(f"Disk Usage: {psutil.disk_usage('/').percent}%")

    tests = {}
    tests['Dashboard'] = subprocess.getoutput("curl -s -o /dev/null -w '%{http_code}' http://localhost/admin")
    tests['GPT UI'] = subprocess.getoutput("curl -s -o /dev/null -w '%{http_code}' http://localhost:1337/chat/")
    tests['Webmin'] = subprocess.getoutput("curl -k -s -o /dev/null -w '%{http_code}' https://localhost:10000")
    tests['Watchdog'] = subprocess.getoutput("systemctl is-active fortresspi_watchdog || echo inactive")
    tests['Docker'] = 'running' if 'CONTAINER' in subprocess.getoutput('docker ps') else 'not running'

    tests_out = '\n'.join(f"{k}: {v}" for k, v in tests.items())
    return render_template('diagnostics.html', metrics='\n'.join(metrics), tests=tests_out)
