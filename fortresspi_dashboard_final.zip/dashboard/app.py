#!/usr/bin/env python3
from flask import Flask, render_template, request, redirect, url_for
import subprocess

app = Flask(__name__)

def run(cmd):
    return subprocess.getoutput(cmd)

@app.route('/')
def index():
    status = {
        'gpt4free': 'g4f' in run("docker ps"),
        'upload_cli': 'active' in run("systemctl is-active upload-panel-cli.service"),
        'watchdog': 'active' in run("systemctl is-active fortresspi_watcher.timer"),
        'webhook': 'active' in run("systemctl is-active fortresspi_webhook.service")
    }
    return render_template('index.html', status=status)

@app.route('/restart/<service>')
def restart(service):
    if service == "gpt4free":
        run("cd /home/pi/gpt4free && docker compose restart")
    else:
        run(f"systemctl restart {service}")
    return redirect(url_for('index'))

@app.route('/logs/<target>')
def logs(target):
    if target == "gpt4free":
        out = run("docker logs g4f --tail 100")
    else:
        out = run(f"journalctl -u {target} -n 100")
    return f"<pre>{out}</pre>"

@app.route('/backup')
def manual_backup():
    out = run("/usr/local/bin/fortresspi_backup.sh")
    return f"<pre>{out}</pre>"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8090)
