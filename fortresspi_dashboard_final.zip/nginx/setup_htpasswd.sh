#!/bin/bash
set -e
echo "[*] Creating NGINX HTTP basic auth for /admin/..."
apt-get install -y apache2-utils
htpasswd -cb /etc/nginx/.htpasswd admin fortresspi
systemctl restart nginx
echo "[✔] Basic auth created: user 'admin', password 'fortresspi'"
